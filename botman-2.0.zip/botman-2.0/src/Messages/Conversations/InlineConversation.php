<?php

namespace BotMan\BotMan\Messages\Conversations;

class InlineConversation extends Conversation
{
    public function run()
    {
        //
    }
}
