<?php

namespace BotMan\BotMan\Exceptions\Core;

use BotMan\BotMan\Exceptions\Base\BotManException;

class UnexpectedValueException extends BotManException
{
}
