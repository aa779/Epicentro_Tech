<?php

namespace BotMan\BotMan\Exceptions\Base;

use Exception;

class BotManException extends Exception
{
}
