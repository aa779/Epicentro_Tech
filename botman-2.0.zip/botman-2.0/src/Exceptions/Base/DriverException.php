<?php

namespace BotMan\BotMan\Exceptions\Base;

class DriverException extends BotManException
{
}
